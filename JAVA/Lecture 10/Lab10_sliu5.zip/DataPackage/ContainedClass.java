package DataPackage;

public class ContainedClass {
    private String ccString = "";

    public void setCcString(String ccString) {
        this.ccString = ccString;
    }

    public String getCcString() {
        return ccString;
    }
}
